#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

clear
# ခေါင်းစီးလိုဂိုအား PS UDP သို့ ပြောင်းလဲထားခြင်း
echo -e "          ░█▀▀█ ░█▀▀▀█ 　 ░█─░█ ░█▀▀▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄█ ─▀▀▀▄▄ 　 ░█─░█ ░█─░█ ░█▄▄█ " | lolcat
echo -e "          ░█─── ░█▄▄▄█ 　 ─▀▄▄▀ ░█▄▄▀ ░█─── " | lolcat

echo ""
echo ""
echo -e "${YELLOW}  [ ဆာဗာပေါ်ရှိ အသုံးပြုသူ (User) စာရင်း ]${ENDCOLOR}"
echo "--------------------------------------------------"
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}$allusers${ENDCOLOR}"
echo "--------------------------------------------------"
echo ""

# အကောင့်ဖျက်ရန် နာမည်တောင်းခြင်း
echo -ne "${YELLOW} • ဖျက်ပစ်မည့် အသုံးပြုသူအမည် (User Name) ကို ရိုက်ထည့်ပါ : ${ENDCOLOR}"; read username

# သေချာမသေချာ ထပ်မံအတည်ပြုခိုင်းခြင်း (Yes/No အစား Y/N ဖြင့် ဆက်လက်အလုပ်လုပ်ပါမည်)
while true; do
    read -p "အသုံးပြုသူ '$username' ကို စနစ်ထဲမှ အပြီးတိုင် ဖျက်ပစ်ရန် သေချာပါသလား? (Y/N) " yn
    case $yn in
        [Yy]* ) 
            userdel $username && echo "" && echo -e "${RED}[အောင်မြင်သည်] အသုံးပြုသူ '$username' ကို စနစ်ထဲမှ ဖျက်ပစ်လိုက်ပါပြီ။${ENDCOLOR}" || echo -e "${RED}[မအောင်မြင်ပါ] အသုံးပြုသူ '$username' ကို ဖျက်၍မရပါ။${ENDCOLOR}"
            break
            ;;
        [Nn]* ) 
            echo -e "${RED}\nအကောင့်ဖျက်ခြင်းကို ပယ်ဖျက်လိုက်ပါသည်။${ENDCOLOR}"
            break
            ;;
        * ) 
            echo "ကျေးဇူးပြု၍ Y (ဖျက်မည်) သို့မဟုတ် N (မဖျက်ပါ) ဟုသာ ဖြေပေးပါ။"
            ;;
    esac
done

echo -e "\nမနူး (Main Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
menu
