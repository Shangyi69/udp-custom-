#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

clear
# ခေါင်းစီးလိုဂိုအား PS UDP သို့ ပြောင်းလဲထားခြင်း
echo -e "          ░█▀▀█ ░█▀▀▀█ 　 ░█─░█ ░█▀▀▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄█ ─▀▀▀▄▄ 　 ░█─░█ ░█─░█ ░█▄▄█ " | lolcat
echo -e "          ░█─── ░█▄▄▄█ 　 ─▀▄▄▀ ░█▄▄▀ ░█─── " | lolcat
echo ""
echo ""
echo -e "$CYAN      ╔═══════════════════════════════════════╗$ENDCOLOR"
echo -e "$CYAN      ║         ${YELLOW}☆ အကောင့်အသစ် ဆောက်ခြင်း ☆        ${CYAN}║$ENDCOLOR"
echo -e "$CYAN      ╚═══════════════════════════════════════╝$ENDCOLOR"
echo ""

# ၁။ အသုံးပြုသူအမည် (Username) တောင်းခြင်း
echo -ne "${GREEN} • အသုံးပြုသူအမည် (Username) ထည့်ပါ : ${ENDCOLOR}" ; read username

# အကောင့်ရှိပြီးသားဖြစ်နေလျှင် သတိပေးရန်
if id "$username" &>/dev/null; then
    echo -e "${RED}\n[အမှား] အသုံးပြုသူအမည် '$username' သည် ဆာဗာပေါ်တွင် ရှိနှင့်ပြီးသား ဖြစ်နေပါသည်။${ENDCOLOR}"
    echo -e "\nမနူး (Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
    menu
    exit 1
fi

# ၂။ စကားဝှက် (Password) တောင်းခြင်း
echo -ne "${GREEN} • စကားဝှက် (Password) ထည့်ပါ : ${ENDCOLOR}" ; read password

# ၃။ သက်တမ်း ကန့်သတ်မည့် ရက်အရေအတွက် တောင်းခြင်း
echo -ne "${GREEN} • အသုံးပြုနိုင်မည့် ရက်အရေအတွက် (Days) ထည့်ပါ : ${ENDCOLOR}" ; read days

# ရက်နေရာတွင် ဂဏန်းဟုတ်မဟုတ် စစ်ဆေးခြင်း
if [[ ! "$days" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}\n[အမှား] ရက်အရေအတွက်သည် ဂဏန်းအမှန် ဖြစ်ရပါမည်။${ENDCOLOR}"
    echo -e "\nမနူး (Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
    menu
    exit 1
fi

# ရက်စွဲကို Linux စနစ်အတွက် YYYY-MM-DD ပုံစံ တွက်ချက်ခြင်း
expire_date=$(date -d "today + $days days" +%Y-%m-%d)

# ၄။ Linux စနစ်ထဲသို့ အကောင့်အသစ် ထည့်သွင်းခြင်း Logic
# အသုံးပြုသူ ဆောက်သည်၊ စကားဝှက် သတ်မှတ်သည်၊ သက်တမ်းကုန်ရက် ထည့်သွင်းသည်
useradd -M -s /bin/false "$username"
echo "$username:$password" | chpasswd
chage -E "$expire_date" "$username"

# ၅။ SSHPlus ပုံစံအတိုင်း Password ကို ဖိုင်ထဲတွင် မှတ်မ်းတင်သိမ်းဆည်းခြင်း (မူရင်း Logic)
mkdir -p /etc/SSHPlus/Password
echo "$password" > "/etc/SSHPlus/Password/$username"

# ၆။ အောင်မြင်ကြောင်း ပြသခြင်း
clear
echo -e "          ░█▀▀█ ░█▀▀▀█ 　 ░█─░█ ░█▀▀▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄█ ─▀▀▀▄▄ 　 ░█─░█ ░█─░█ ░█▄▄█ " | lolcat
echo -e "          ░█─── ░█▄▄▄█ 　 ─▀▄▄▀ ░█▄▄▀ ░█─── " | lolcat
echo ""
echo -e "$GREEN==================================================$ENDCOLOR"
echo -e "$YELLOW     အကောင့်အသစ် ဆောက်ခြင်း အောင်မြင်ပါသည်!$ENDCOLOR"
echo -e "$GREEN==================================================$ENDCOLOR"
echo -e "${CYAN}အသုံးပြုသူအမည် :$ENDCOLOR $username"
echo -e "${CYAN}စကားဝှက်       :$ENDCOLOR $password"
echo -e "${CYAN}အသုံးပြုနိုင်မည့်ရက်:$ENDCOLOR $days ရက်"
echo -e "${CYAN}သက်တမ်းကုန်ရက် :$ENDCOLOR $(date -d "$expire_date" "+%d %b %Y")"
echo -e "$GREEN==================================================$ENDCOLOR"

echo -e "\nမနူး (Main Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
menu
