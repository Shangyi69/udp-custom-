#!/bin/bash

GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

clear
# ခေါင်းစီးလိုဂိုအား SSLAB UDP မှ PS UDP သို့ ပြောင်းလဲထားခြင်း
echo -e "          ░█▀▀█ ░█▀▀▀█ 　 ░█─░█ ░█▀▀▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄█ ─▀▀▀▄▄ 　 ░█─░█ ░█─░█ ░█▄▄█ " | lolcat
echo -e "          ░█─── ░█▄▄▄█ 　 ─▀▄▄▀ ░█▄▄▀ ░█─── " | lolcat
echo ""
echo ""

# ဇယားကွက် ခေါင်းစဉ်များ
echo -e "${YELLOW}--------------------------------------------------${ENDCOLOR}"
printf "${CYAN}%-20s %-15s %-15s${ENDCOLOR}\n" "အသုံးပြုသူအမည်" "သက်တမ်းကုန်ရက်" "အခြေအနေ"
echo -e "${YELLOW}--------------------------------------------------${ENDCOLOR}"

# /etc/passwd ထဲမှ ပုံမှန်အသုံးပြုသူများကို တစ်ယောက်ချင်းစီ ထုတ်ယူပြီး ရက်စွဲစစ်ဆေးခြင်း
for username in $(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody); do
    
    # Linux စနစ်ထဲမှ အကောင့်တစ်ခုချင်းစီ၏ Expire Date ကို ရှာဖွေခြင်း
    expire_str=$(chage -l "$username" | awk -F': ' '/Account expires/ {print $2}' | xargs)
    
    # အကယ်၍ ရက်စွဲသတ်မှတ်မထားပါက သို့မဟုတ် 'never' ဖြစ်နေပါက 'သက်တမ်းမကုန်ပါ' ဟု ပြမည်
    if [ -z "$expire_str" ] || [ "$expire_str" == "never" ]; then
        expire_display="သက်တမ်းမကုန်ပါ"
    else
        # ရက်စွဲကို ဖတ်ရလွယ်ကူအောင် ပြောင်းလဲခြင်း (ဥပမာ - 16 Jun 2026)
        expire_display=$(date -d "$expire_str" "+%d %b %Y" 2>/dev/null)
    fi

    # အကောင့်ပိတ်ထားခြင်း (L) သို့မဟုတ် ပွင့်နေခြင်း (P) ကို စစ်ဆေးခြင်း
    status_raw=$(passwd -S "$username" 2>/dev/null | awk '{print $2}')
    if [ "$status_raw" == "L" ]; then
        status_display="ပိတ်ထားသည် (Locked)"
    else
        status_display="အသုံးပြုနိုင် (Active)"
    fi

    # ဇယားကွက်ထဲသို့ အချက်အလက်များ လှပစွာ ထည့်သွင်းပြသခြင်း
    printf "${GREEN}%-20s %-15s %-15s${ENDCOLOR}\n" "$username" "$expire_display" "$status_display"
done

echo -e "${YELLOW}--------------------------------------------------${ENDCOLOR}"

echo -e "\nမနူး (Main Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
menu
