#!/bin/bash
# CheckExpired.sh
# Auto-locks Linux accounts whose "Account expires" date has passed,
# then restarts udp-custom so already-connected (cached) sessions get dropped.
#
# Install:
#   cp CheckExpired.sh /etc/Sslablk/system/
#   chmod +x /etc/Sslablk/system/CheckExpired.sh
#
# Cron (run every 5 minutes):
#   crontab -e
#   */5 * * * * /etc/Sslablk/system/CheckExpired.sh

LOGFILE="/var/log/udp-expiry-check.log"
TODAY_EPOCH=$(date +%s)
RESTART_NEEDED=0

for username in $(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody); do

    # "Account expires" line from chage -l, e.g. "Account expires : 2026-06-20" or "never"
    expire_str=$(chage -l "$username" | awk -F': ' '/Account expires/ {print $2}' | xargs)

    if [ -z "$expire_str" ] || [ "$expire_str" == "never" ]; then
        continue
    fi

    expire_epoch=$(date -d "$expire_str" +%s 2>/dev/null)
    [ -z "$expire_epoch" ] && continue

    if [ "$TODAY_EPOCH" -ge "$expire_epoch" ]; then
        # passwd -S output: username status ...   (status "L" = locked, "P" = usable)
        status=$(passwd -S "$username" 2>/dev/null | awk '{print $2}')

        if [ "$status" != "L" ]; then
            usermod -L "$username"
            echo "$(date '+%Y-%m-%d %H:%M:%S') - $username expired ($expire_str) -> locked" >> "$LOGFILE"
            RESTART_NEEDED=1
        fi
    fi
done

# udp-custom keeps already-authenticated sessions cached in memory,
# so locking the account alone won't drop an existing tunnel.
# Restart the service to force everyone to re-authenticate.
if [ "$RESTART_NEEDED" -eq 1 ]; then
    systemctl restart udp-custom
    echo "$(date '+%Y-%m-%d %H:%M:%S') - udp-custom restarted to drop expired sessions" >> "$LOGFILE"
fi
