#!/bin/bash

# သက်တမ်းကုန်ဆုံးမှု မှတ်တမ်းသိမ်းမည့် လမ်းကြောင်း
LOGFILE="/var/log/udp-expiry-check.log"

# ယနေ့ရက်စွဲကို ရယူခြင်း (Format: YYYY-MM-DD)
TODAY_DATE=$(date +%Y-%m-%d)

# UDP Custom Service ကို Restart ချရန် လိုမလို မှတ်သားမည့် Variable
RESTART_NEEDED=0

# Linux ဆာဗာပေါ်ရှိ ပုံမှန်အသုံးပြုသူ (Users) အားလုံးကို တစ်ယောက်ချင်းစီ စစ်ဆေးခြင်း
for username in $(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody); do
    
    # အကောင့်တစ်ခုချင်းစီ၏ သက်တမ်းကုန်မည့်ရက် (Account expires) ကို ရှာဖွေခြင်း
    expire_str=$(chage -l "$username" | awk -F': ' '/Account expires/ {print $2}' | xargs)
    
    # အကယ်၍ သက်တမ်းသတ်မှတ်မထားပါက သို့မဟုတ် 'never' ဖြစ်နေပါက ကျော်သွားမည်
    if [ -z "$expire_str" ] || [ "$expire_str" == "never" ]; then
        continue
    fi

    # သက်တမ်းကုန်မည့်ရက်စွဲကို Format ပြောင်းလဲခြင်း
    expire_date=$(date -d "$expire_str" +%Y-%m-%d 2>/dev/null)
    
    # ယနေ့ရက်စွဲသည် သက်တမ်းကုန်မည့်ရက်သို့ ရောက်ရှိလျှင် သို့မဟုတ် ကျော်လွန်သွားလျှင်
    if [[ "$TODAY_DATE" > "$expire_date" ]] || [[ "$TODAY_DATE" == "$expire_date" ]]; then
        
        # အကောင့်၏ လက်ရှိ အခြေအနေကို စစ်ဆေးခြင်း (L = Locked, P = Active)
        status=$(passwd -S "$username" 2>/dev/null | awk '{print $2}')
        
        # အကယ်၍ အကောင့်က ပိတ်မထားရသေးပါက စတင်ပိတ်မည်
        if [ "$status" != "L" ]; then
            # အကောင့်ကို အလိုအလျောက် ပိတ်ဆို့ခြင်း (Lock)
            usermod -L "$username"
            
            # Logဖိုင်ထဲတွင် မှတ်တမ်းရေးသွင်းခြင်း
            echo "$(date '+%Y-%m-%d %H:%M:%S')... Account $username expired and has been locked." >> "$LOGFILE"
            
            # Restart ချရန် လိုအပ်ကြောင်း အတည်ပြုခြင်း
            RESTART_NEEDED=1
        fi
    fi
done

# သက်တမ်းကုန်၍ ပိတ်လိုက်ရသော အကောင့်ရှိခဲ့ပါက ၎င်းတို့ချိတ်ထားသော VPN လိုင်းဟောင်းများ ပြတ်တောက်သွားစေရန်
# udp-custom service ကို အလိုအလျောက် Restart ချပေးခြင်း
if [ "$RESTART_NEEDED" -eq 1 ]; then
    systemctl restart udp-custom
fi
