#!/bin/bash
# သက်တမ်းကုန်ဆုံးမှု မှတ်တမ်းသိမ်းမည့် လမ်းကြောင်း
LOGFILE="/var/log/udp-expiry-check.log"

# လက်ရှိအချိန်ကို စက္ကန့် (Unix Epoch Time) ဖြင့် ရယူခြင်း
NOW_EPOCH=$(date +%s)

# UDP Custom Service ကို Restart ချရန် လိုမလို မှတ်သားမည့် Variable
RESTART_NEEDED=0

# Linux ဆာဗာပေါ်ရှိ ပုံမှန်အသုံးပြုသူ (Users) အားလုံးကို တစ်ယောက်ချင်းစီ စစ်ဆေးခြင်း
for username in $(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody); do
    # အကောင့်တစ်ခုချင်းစီ၏ သက်တမ်းကုန်မည့် ရက်စွဲစာသားကို ယူသည်
    expire_str=$(chage -l "$username" | awk -F': ' '/Account expires/ {print $2}' | xargs)
    
    # အကယ်၍ ရက်စွဲသတ်မှတ်မထားပါက သို့မဟုတ် 'never' ဖြစ်နေပါက ကျော်သွားမည်
    if [ -z "$expire_str" ] || [ "$expire_str" == "never" ]; then
        continue
    fi

    # ၎င်းရက်စွဲကို စက္ကန့် (Epoch Time) အဖြစ် ပြောင်းလဲသည်
    expire_epoch=$(date -d "$expire_str" +%s 2>/dev/null)
    
    # အကယ်၍ ဆာဗာ၏ ရက်စွဲ Format ကြောင့် (ဥပမာ MM/DD/YYYY) date command က အလုပ်မလုပ်လျှင် Format ပြောင်း၍ ထပ်စမ်းသည်
    if [ -z "$expire_epoch" ]; then
        expire_epoch=$(date -d "$(echo "$expire_str" | awk -F'/' '{print $3"-"$1"-"$2}')" +%s 2>/dev/null)
    fi

    # ရက်စွဲကို စက္ကန့်အဖြစ် ပြောင်းလဲ၍မရသေးပါက အမှားမတက်စေရန် ကျော်သွားမည်
    if [ -z "$expire_epoch" ]; then
        continue
    fi

    # လက်ရှိအချိန်စက္ကန့်သည် သက်တမ်းကုန်ရက်စက္ကန့်ထက် ကြီးသွားလျှင် (သို့မဟုတ်) တူသွားလျှင်
    if [ "$NOW_EPOCH" -ge "$expire_epoch" ]; then
        # အကောင့်၏ လက်ရှိ အခြေအနေကို စစ်ဆေးခြင်း (L = Locked, P = Active)
        status=$(passwd -S "$username" 2>/dev/null | awk '{print $2}')
        
        # အကယ်၍ အကောင့်က ပိတ်မထားရသေးပါက စတင်ပိတ်မည်
        if [ "$status" != "L" ]; then
            # အကောင့်ကို အလိုအလျောက် ပိတ်ဆို့ခြင်း (Lock)
            usermod -L "$username"
            
            # Logဖိုင်ထဲတွင် မှတ်တမ်းရေးသွင်းခြင်း
            echo "$(date '+%Y-%m-%d %H:%M:%S')... Account $username expired and has been locked." >> "$LOGFILE"
            
            # Restart ချရန် လိုအပ်ကြောင်း အတည်ပြုခြင်း
            RESTART_NEEDED=1
        fi
    fi
done

# သက်တမ်းကုန်၍ ပိတ်လိုက်ရသော အကောင့်ရှိခဲ့ပါက ၎င်းတို့ချိတ်ထားသော VPN လိုင်းဟောင်းများ ပြတ်တောက်သွားစေရန်
# udp-custom service ကို အလိုအလျောက် Restart ချပေးခြင်း
if [ "$RESTART_NEEDED" -eq 1 ]; then
    systemctl restart udp-custom
fi
