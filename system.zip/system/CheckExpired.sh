#!/bin/bash
# =================================================================
# စနစ်အမည် - အလိုအလျောက် သက်တမ်းကုန်အကောင့် စစ်ဆေးပိတ်ဆို့ခြင်း စနစ်
# ဗားရှင်း   - v1.2 (Timezone & Date Format Bug Fixed)
# =================================================================

# ၁။ သက်တမ်းကုန်ဆုံးမှု မှတ်တမ်းသိမ်းမည့် လမ်းကြောင်း သတ်မှတ်ခြင်း
LOGFILE="/var/log/udp-expiry-check.log"

# ၂။ ယနေ့ရက်စွဲကို YYYY-MM-DD ပုံစံဖြင့် တိကျစွာ ရယူခြင်း
TODAY_DATE=$(date +%Y-%m-%d)

# UDP Custom Service ကို Restart ချရန် လိုမလို မှတ်သားမည့် ကိန်းရှင် (Variable)
RESTART_NEEDED=0

# ၃။ Linux ဆာဗာပေါ်ရှိ ပုံမှန်အသုံးပြုသူ (Users) အားလုံးကို တစ်ယောက်ချင်းစီ စစ်ဆေးခြင်း
for username in $(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody); do
    
    # အကောင့်တစ်ခုချင်းစီ၏ သက်တမ်းကုန်မည့် ရက်စွဲစာသားကို ဆွဲထုတ်ခြင်း
    expire_str=$(chage -l "$username" | awk -F': ' '/Account expires/ {print $2}' | xargs)
    
    # အကယ်၍ ရက်စွဲသတ်မှတ်မထားပါက သို့မဟုတ် 'never' ဖြစ်နေပါက ကျော်သွားမည်
    if [ -z "$expire_str" ] || [ "$expire_str" == "never" ]; then
        continue
    fi

    # ၎င်းရက်စွဲစာသားကို YYYY-MM-DD ပုံစံသို့ ပြောင်းလဲခြင်း
    expire_date=$(date -d "$expire_str" +%Y-%m-%d 2>/dev/null)
    
    # အကယ်၍ ဆာဗာ၏ ရက်စွဲစနစ်ကြောင့် (ဥပမာ MM/DD/YYYY ဖြစ်နေလျှင်) date command က အလုပ်မလုပ်ပါက Format ပြောင်း၍ ထပ်စမ်းခြင်း
    if [ -z "$expire_date" ]; then
        expire_date=$(date -d "$(echo "$expire_str" | awk -F'/' '{print $3"-"$1"-"$2}')" +%Y-%m-%d 2>/dev/null)
    fi

    # ရက်စွဲထွက်မလာသေးပါက စနစ်အမှားမတက်စေရန် ကျော်သွားမည်
    if [ -z "$expire_date" ]; then
        continue
    fi

    # ၄။ ယနေ့ရက်စွဲသည် သက်တမ်းကုန်ရက်ထက် ကြီးနေလျှင် သို့မဟုတ် တူနေလျှင် (သက်တမ်းကုန်ပြီဟု သတ်မှတ်သည်)
    if [[ "$TODAY_DATE" > "$expire_date" ]] || [[ "$TODAY_DATE" == "$expire_date" ]]; then
        
        # အကောင့်၏ လက်ရှိ အခြေအနေကို စစ်ဆေးခြင်း (L = Locked, P = Active)
        status=$(passwd -S "$username" 2>/dev/null | awk '{print $2}')
        
        # အကယ်၍ အကောင့်က ပိတ်မထားရသေးပါက စတင်ပိတ်ဆို့မည်
        if [ "$status" != "L" ]; then
            
            # အကောင့်ကို အလိုအလျောက် ပိတ်ဆို့ခြင်း (Lock)
            usermod -L "$username"
            
            # Log ဖိုင်ထဲတွင် ရက်စွဲ၊ အချိန်နှင့်တကွ မှတ်တမ်းရေးသွင်းခြင်း
            echo "$(date '+%Y-%m-%d %H:%M:%S')... Account $username expired and has been locked." >> "$LOGFILE"
            
            # ချိတ်ဆက်ထားသော VPN လိုင်းများ ဖြတ်တောက်ရန် Restart ချဖို့ လိုအပ်ကြောင်း မှတ်သားခြင်း
            RESTART_NEEDED=1
        fi
    fi
done

# ၅။ သက်တမ်းကုန်၍ ပိတ်လိုက်ရသော အကောင့်ရှိခဲ့ပါက ၎င်းတို့၏ VPN လိုင်းဟောင်းများ ချက်ချင်းပြတ်တောက်သွားစေရန်
# udp-custom service ကို အလိုအလျောက် Restart ချပေးခြင်း
if [ "$RESTART_NEEDED" -eq 1 ]; then
    systemctl restart udp-custom
fi
 