#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

clear
# ခေါင်းစီးလိုဂိုအား PS UDP သို့ ပြောင်းလဲထားခြင်း
echo -e "          ░█▀▀█ ░█▀▀▀█ 　 ░█─░█ ░█▀▀▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄█ ─▀▀▀▄▄ 　 ░█─░█ ░█─░█ ░█▄▄█ " | lolcat
echo -e "          ░█─── ░█▄▄▄█ 　 ─▀▄▄▀ ░█▄▄▀ ░█─── " | lolcat
echo ""
echo ""
echo -e "$CYAN      ╔═══════════════════════════════════════╗$ENDCOLOR"
echo -e "$CYAN      ║       ${YELLOW}☆ အကောင့်သက်တမ်းတိုးခြင်း ☆       ${CYAN}║$ENDCOLOR"
echo -e "$CYAN      ╚═══════════════════════════════════════╝$ENDCOLOR"
echo ""

# ၁။ အသုံးပြုသူ နာမည်တောင်းခြင်း
echo -ne "${GREEN} • သက်တမ်းတိုးမည့် User Name ထည့်ပါ : ${ENDCOLOR}" ; read username

# အသုံးပြုသူစနစ်ထဲမှာ ရှိမရှိ စစ်ဆေးခြင်း
if ! id "$username" &>/dev/null; then
    echo -e "${RED}\n[အမှား] အသုံးပြုသူ '$username' ကို ဆာဗာပေါ်တွင် ရှာမတွေ့ပါ။${ENDCOLOR}"
    echo -e "\nမနူး (Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
    menu
    exit 1
fi

# ၂။ သက်တမ်းတိုးမည့် ရက်အရေအတွက် တောင်းခြင်း
echo ""
echo -ne "${GREEN} • တိုးမည့် ရက်အရေအတွက် ထည့်ပါ (ဥပမာ- 30) : ${ENDCOLOR}" ; read days

# နံပါတ် ဟုတ်မဟုတ် စစ်ဆေးခြင်း
if [[ ! "$days" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}\n[အမှား] ရက်အရေအတွက်သည် ဂဏန်းအမှန် ဖြစ်ရပါမည်။${ENDCOLOR}"
    echo -e "\nမနူး (Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
    menu
    exit 1
fi

# ၃။ ရက်စွဲကို တွက်ချက်ခြင်း (လက်ရှိနေ့ သို့မဟုတ် ရှိပြီးသား Expire ရက်ပေါ်မူတည်၍ တွက်ချက်ခြင်း)
# အကယ်၍ အကောင့်က သက်တမ်းကုန်ပြီး Lock ကျနေလျှင် ယနေ့မှစ၍ ရက်ပေါင်း ပေါင်းမည်။
# သက်တမ်းမကုန်သေးလျှင် ကျန်ရှိသောရက်ပေါ်တွင် ထပ်ပေါင်းမည်။

current_expire_str=$(chage -l "$username" | awk -F': ' '/Account expires/ {print $2}' | xargs)
today_epoch=$(date +%s)

if [ "$current_expire_str" == "never" ] || [ -z "$current_expire_str" ]; then
    base_date="today"
else
    expire_epoch=$(date -d "$current_expire_str" +%s 2>/dev/null)
    if [ -z "$expire_epoch" ]; then
        # ရက်စွဲ Format လွဲခဲ့လျှင် (MM/DD/YYYY) ပြောင်းတွက်သည်
        expire_epoch=$(date -d "$(echo "$current_expire_str" | awk -F'/' '{print $3"-"$1"-"$2}')" +%s 2>/dev/null)
    fi

    # သက်တမ်းကုန်သွားပြီဆိုလျှင် ယနေ့မှစတွက်မည်၊ မကုန်သေးလျှင် သက်တမ်းကုန်မည့်ရက်မှ ထပ်တိုးမည်
    if [ "$today_epoch" -ge "$expire_epoch" ]; then
        base_date="today"
    else
        base_date=$(date -d "@$expire_epoch" +%Y-%m-%d)
    fi
fi

# ရက်စွဲအသစ် တွက်ချက်ခြင်း
new_expire_date=$(date -d "$base_date + $days days" +%Y-%m-%d)

# ၄။ Linux စနစ်ထဲတွင် ရက်စွဲအသစ်အား Auto Renew လုပ်ခြင်း
chage -E "$new_expire_date" "$username"

# အကယ်၍ အကောင့်က Lock (ပိတ်) မိနေလျှင် Auto ပြန်ဖွင့်ပေးခြင်း (Unlock)
status=$(passwd -S "$username" 2>/dev/null | awk '{print $2}')
if [ "$status" == "L" ]; then
    usermod -U "$username"
fi

# ၅။ အောင်မြင်ကြောင်း ပြသခြင်း
clear
echo -e "          ░█▀▀█ ░█▀▀▀█ 　 ░█─░█ ░█▀▀▄ ░█▀▀█ " | lolcat
echo -e "          ░█▄▄█ ─▀▀▀▄▄ 　 ░█─░█ ░█─░█ ░█▄▄█ " | lolcat
echo -e "          ░█─── ░█▄▄▄█ 　 ─▀▄▄▀ ░█▄▄▀ ░█─── " | lolcat
echo ""
echo -e "$GREEN==================================================$ENDCOLOR"
echo -e "$YELLOW   အကောင့် သက်တမ်းတိုးခြင်း အောင်မြင်ပါသည်!$ENDCOLOR"
echo -e "$GREEN==================================================$ENDCOLOR"
echo -e "${CYAN}အသုံးပြုသူအမည် :$ENDCOLOR $username"
echo -e "${CYAN}တိုးပေးသည့်ရက်  :$ENDCOLOR $days ရက်"
echo -e "${CYAN}သက်တမ်းကုန်ရက် :$ENDCOLOR $(date -d "$new_expire_date" "+%d %b %Y")"
echo -e "$GREEN==================================================$ENDCOLOR"

echo -e "\nမနူး (Main Menu) သို့ ပြန်သွားရန် Enter နှိပ်ပါ"; read
menu
